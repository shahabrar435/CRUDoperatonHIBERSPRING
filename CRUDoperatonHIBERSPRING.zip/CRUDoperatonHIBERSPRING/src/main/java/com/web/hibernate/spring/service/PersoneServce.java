package com.web.hibernate.spring.service;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.hibernate.spring.dao.PersonDAO;
import com.web.hibernate.spring.dto.PersonDTO;

@Service
public class PersoneServce {

	@Autowired
	private PersonDAO dao;
	
	
	
	public boolean registerUser(PersonDTO dto) {
		return dao.register(dto);
	}

	public JSONObject login(String username, String password) {
		return dao.login(username, password);
	}
	public boolean updateUser(PersonDTO personDTO) {
		return dao.saveTranscation(personDTO);
	}
	public int removePerson(int id)
	{
		return dao.deactivate(id);
	}
}
