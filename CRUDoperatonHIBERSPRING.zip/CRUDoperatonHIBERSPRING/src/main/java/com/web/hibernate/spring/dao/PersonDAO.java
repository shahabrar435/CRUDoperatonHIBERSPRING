package com.web.hibernate.spring.dao;

import java.time.LocalDateTime;

import javax.persistence.EntityManagerFactory;
import javax.transaction.Transactional;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.web.hibernate.spring.dto.PersonDTO;

@Repository
@Transactional 
public class PersonDAO {
	@Autowired
	private SessionFactory factory;
	
	public PersonDAO(EntityManagerFactory factory) {
		if(factory.unwrap(SessionFactory.class) == null){
		      throw new NullPointerException("factory is not a hibernate factory");
		    }
		    this.factory = factory.unwrap(SessionFactory.class);
	}
	
	public JSONObject login(String username, String password) {
		Session session = factory.openSession();
		System.out.println("personDAO.login()");
		String hql = "" ;
		Query query=null;
		String sql = "select * from person where username=:username and  password=:password";
		
		long id = 0;
		JSONObject obj = new JSONObject();
		try {
			
			SQLQuery sqlQuery = session.createSQLQuery(sql);
			sqlQuery.setParameter("username", username);
			sqlQuery.setParameter("password", password);
			sqlQuery.addEntity(PersonDTO.class);
			PersonDTO personDTO=(PersonDTO) sqlQuery.uniqueResult();
			System.out.println(personDTO);
			if (personDTO != null) {
//				id = personDTO.getId();
//				String lastLogin = LocalDateTime.now().toString();
//				hql = "update person set last_login=:logintime where id=:id";
//				Transaction tx = session.beginTransaction();
//				query = session.createQuery(hql);
//				query.setParameter("logintime", lastLogin);
//				query.setParameter("id", id);
//				query.executeUpdate();
//				tx.commit();
				obj.put("person", personDTO); 
				return obj;
			}
			
			
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean register(PersonDTO personDTO) {
		System.out.println("personDAO.register()");
		Session session = factory.openSession();
		try {
			
			Transaction tx = session.beginTransaction();
			session.saveOrUpdate(personDTO);
			tx.commit();
			session.close();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean saveTranscation(PersonDTO person) {
		System.out.println("PersonDAO.saveTranscation()");
		Session session = factory.openSession();
		try {
			
			Transaction tx = session.beginTransaction();
			//session.saveOrUpdate(user);  
			session.merge(person);
			tx.commit();
			return true;
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		
		return false;
	}
	


	public int deactivate(int id) {
		System.out.println(id);		
		System.out.println("personDao.deactivate()");
		JSONObject object = new JSONObject();
		Session session = factory.openSession();
		Transaction tr = session.beginTransaction();
		String str = "delete from person where id=:id ";
		SQLQuery qry = session.createSQLQuery(str);
		qry.setParameter("id", id);
		System.out.println(id);
		int x = qry.executeUpdate();
		tr.commit();
		if (x > 0) {
			return 1;
		}
		return 0;

}
}
