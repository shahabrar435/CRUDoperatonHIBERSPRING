package com.web.hibernate.spring.controller;



import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.web.hibernate.spring.dao.PersonDAO;
import com.web.hibernate.spring.dto.PersonDTO;
import com.web.hibernate.spring.service.PersoneServce;

@Controller
public class PersonController {
	
	@Autowired
	PersoneServce service;

	@RequestMapping("/")
	public String index() {
		return "register";
	}

//	@RequestMapping(value = "/login", method = RequestMethod.GET)
//	public String displayCustomerForm(ModelMap model) {
//		model.addAttribute("PersonDTO", new PersonDTO());
//		return "login";
//	}
	
	@PostMapping("/login")
	public ModelAndView login(@ModelAttribute PersonDTO personDTO, HttpServletRequest request) {
		System.out.println("person.login()");
		System.out.println(personDTO);
		// JSONObject obj= dao.login(userDTO.getEmail(), userDTO.getPassword());
		JSONObject obj = service.login(personDTO.getUsername(), personDTO.getPassword());
		if (obj != null) {
			System.out.println("Login Success");
			PersonDTO dto = (PersonDTO) obj.get("person");
			System.out.println("Name: " + dto.getUsername());
			HttpSession personSession = request.getSession();
			personSession.setAttribute("persondetails", obj);
             
			// userSession.setMaxInactiveInterval(99*9999);
		personDTO = (PersonDTO) obj.get("person");
			System.out.println("Name: " + personDTO.getUsername());
			return new ModelAndView("/update", "name", personDTO.getUsername());
		} else {
			request.setAttribute("msg", "Invalid username or password");
			return new ModelAndView("/login");
		}

	}
	@RequestMapping("/register")
	public String register(@Valid PersonDTO personDTO, BindingResult result) {

		System.out.println("User.register()");

		if (result.hasErrors()) {
			System.out.println("JSR Validation");
			return "loginJSR.jsp";
		}

		boolean val = false;
		String msg = "";
		
			try {

				
				val = service.registerUser(personDTO);
				msg = "";				
			} catch (Exception e) {
				System.out.println(e);
			}
		

		// boolean val=dao.register(userDTO);
		val = service.registerUser(personDTO);
		if (val) {
			msg = "Registred Successfully";
		} else {
			msg = "Registration Failed";
		}
		System.out.println(msg);
		// return new ModelAndView("/login.jsp", "msg", msg);
		return "login";
	}

	@RequestMapping("/update")
	public ModelAndView updateUser(HttpSession session, @ModelAttribute PersonDTO personDTO,
			 HttpServletRequest request) {
		System.out.println("person.updateUser()");

		String password = request.getParameter("password");

		HttpSession sess = request.getSession(false);
		JSONObject obj = (JSONObject) sess.getAttribute("persondetails");
		System.out.println("obj"+obj);
		PersonDTO  person= (PersonDTO) obj.get("person");

		System.out.println("pass: " + password);
		 if (password.equals("")) {
			System.out.println("failed");
		
		}
		 person.setPassword(password);

		boolean val = false;
		String msg = "";

	


		val = service.updateUser(person);

		if (val) {
			msg = "Update Successfully!!!";
		} else {
			msg = "Update Failed!!";
		}
		System.out.println(msg);
		return new ModelAndView("/delete", "msg", msg);
	}
	
	
	@RequestMapping("/delete")
    public String deactivate( int id){
		
       service.removePerson(id);

        return "index";
    }
 


}
